package com.example.android.networkconnect;

/**
 * Created by lucadn on 4/18/14.
 */
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.TextView;

public class ShowSettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_settings_layout);

        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        StringBuilder builder = new StringBuilder();

        builder.append("  Current settings\n\n");

        builder.append("  Number of measurements: " + sharedPrefs.getString("numMeasurements","error"));
        if(sharedPrefs.getBoolean("local_storage",false))
            builder.append("\n  Local storage of measurements: " + "On");
        else
            builder.append("\b  Local storage of measurements: " + "Off");
        builder.append("\n  Local storage file name: " + sharedPrefs.getString("TPName","error"));
        builder.append("\n  Positioning algorithm: " + sharedPrefs.getString("pos_Algorithm","error"));
        builder.append("\n  k selection strategy: " + sharedPrefs.getString("kStrategy","error"));
        builder.append("\n  Threshold selection strategy (EWkNN): " + sharedPrefs.getString("thresholdStrategy","error"));
        builder.append("\n  k value: " + sharedPrefs.getString("kValue","error"));
        builder.append("\n  alpha value (FI-WkNN): " + sharedPrefs.getString("alphaValue","error"));
        builder.append("\n  Order p for Minkowski distance: " + sharedPrefs.getString("pValue","error"));
        builder.append("\n  Similarity metric: " + sharedPrefs.getString("metric","error"));
        builder.append("\n  Threshold 1 (EWkNN): " + sharedPrefs.getString("threshold1","error"));
        builder.append("\n  Threshold 2 (EWkNN): " + sharedPrefs.getString("threshold2","error"));

        //builder.append("\n" + sharedPrefs.getString("welcome_message", "NULL"));

        TextView settingsTextView = (TextView) findViewById(R.id.settings_text_view);
        settingsTextView.setText(builder.toString());

    }

}

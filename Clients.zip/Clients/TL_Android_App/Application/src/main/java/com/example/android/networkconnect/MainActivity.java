/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.networkconnect;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Sample Activity demonstrating how to connect to the network and fetch raw
 * HTML. It uses a Fragment that encapsulates the network operations on an AsyncTask.
 *
 * This sample uses a TextView to display output.
 */
public class MainActivity extends FragmentActivity implements DownloadCallback {

    // Reference to the TextView showing fetched data, so we can clear it with a button
    // as necessary.
    // The ThingSpeak Channel ID
    // Replace this with the Channel IDs of the RSSI Channels of your TL deployment
    static final String channelIDList[] = {"432763", "432764", "432776", "432777", "432778", "432781", "432782", "432783", "432785", "432786", "432789", "432790", "432793"};
    SharedPreferences sharedPrefs;
    int maxNumAPs=(channelIDList.length - 1)*3;
    int currentNumAPs=0;
    int numMeasurements;//=1;
    int numRequiredChannels=0;
    int numSentAPs=0;
    int APsOnLastChannel=0;
    int remainingMeasurements=0;//=numMeasurements;
    String fName;//="TP_Android_7bis.txt";
    // Replace this with the Write API keys of the RSSI Channels of your TL deployment
    static final String writeAPIKeyList[] = {"TMQQB6B42WE4BOT8", "7G4RCF1591RC1BIL", "GYRZQE8I148V6M1G", "LF44P87U1FI4C468", "LCP4K7O7VNHC1WLH", "F2MR0SCC55PXVBTD", "ER8OML0JJOWHJDJ1", "QRQXFASVNOVDPCG9", "L6IUPR139G0DACFO", "GG7CG6AMHO7OPQM5", "ASVO3H3J4CHX2G67", "THE7ROFCLK9GEIO6", "DZY15YB03XILPFD7"};
    String POS_ALGORITHM;//="WKNN";
    int kValue;//=3;
    String metric;//="Minkowski";
    int pValue;//=2;
    String thresholdStrategy;//="DynamicThreshold";
    String kStrategy;//="StaticK";
    double alphaValue=0.001;
    int EWKNNThreshold1=0;
    int EWKNNThreshold2=0;


    private static final String TAG = "UsingThingspeakAPI";
    private static final String THINGSPEAK_CHANNEL_ID = "REPLACE_WITH_YOUR_CHANNEL_ID";
    private static final String THINGSPEAK_API_KEY = "REPLACE_WITH_YOUR_API_KEY";
    private static final String THINGSPEAK_API_KEY_STRING = "api_key";

    /* Be sure to use the correct fields for your own app*/
    private static final String THINGSPEAK_FIELD1 = "field1";
    private static final String THINGSPEAK_FIELD2 = "field2";
    private static final String THINGSPEAK_FIELD3 = "field3";
    private static final String THINGSPEAK_FIELD4 = "field4";
    private static final String THINGSPEAK_FIELD5 = "field5";
    private static final String THINGSPEAK_FIELD6 = "field6";
    private static final String THINGSPEAK_FIELD7 = "field7";
    private static final String THINGSPEAK_FIELD8 = "field8";

    private static final String THINGSPEAK_UPDATE_URL = "https://api.thingspeak.com/update?";
    private static final String THINGSPEAK_CHANNEL_URL = "https://api.thingspeak.com/channels/";
    private static final String THINGSPEAK_FEEDS_LAST = "/feeds/last?";

    private TextView mDataText;
    String android_id;
    List<ScanResult> results;
    myReceiver WFScanReceiver;
    String urlAddress;
    WifiManager wifi;
    ListView lv;
    SimpleAdapter adapter;
    //ArrayList<HashMap<String, Float>> arraylist = new ArrayList<HashMap<String, Float>>();
    ArrayList<HashMap<String, String>> arraylist = new ArrayList<HashMap<String, String>>();
    ArrayList<Object []> cumulativeAPList = new ArrayList<Object []>();
    ArrayList<Object []> averagedAPList = new ArrayList<Object []>();
    int size = 0;
    // Keep a reference to the NetworkFragment which owns the AsyncTask object
    // that is used to execute network ops.
    private NetworkFragment mNetworkFragment;

    // Boolean telling us whether a download is in progress, so we don't trigger overlapping
    // downloads with consecutive button clicks.
    private boolean mDownloading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPrefs=PreferenceManager.getDefaultSharedPreferences(this);
        //Intent intent = getIntent();
        //setContentView(R.layout.sample_main);
        setContentView(R.layout.activity_wifi_demo);
        //mDataText = (TextView) findViewById(R.id.data_text);
        //mNetworkFragment = NetworkFragment.getInstance(getSupportFragmentManager(), "https://www.google.com");
        android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        lv = (ListView)findViewById(R.id.list);

        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
/*        if(wifi==null)
        {
            Toast.makeText(getApplicationContext(), "wifi was not detected", Toast.LENGTH_LONG).show();
        }
            else
        {
            Toast.makeText(getApplicationContext(), "wifi was detected", Toast.LENGTH_LONG).show();
        }
*/
        if (!wifi.isWifiEnabled() )
        {
            //Toast.makeText(getApplicationContext(), "wifi is disabled..making it enabled", Toast.LENGTH_LONG).show();
            wifi.setWifiEnabled(true);
        }
        else
        {
            //Toast.makeText(getApplicationContext(), "wifi already enabled", Toast.LENGTH_LONG).show();
            wifi.setWifiEnabled(true);
        }
        String[] from=new String[]{ "SSID", "Level"};
        int []to=new int[] { R.id.SSID, R.id.Level};
        this.adapter = new SimpleAdapter(this, arraylist, R.layout.row,from , to);
        //this.adapter = new SimpleAdapter(WifiDemo.this, arraylist, R.layout, new String[] { ITEM_KEY }, new int[] { R.id });
        lv.setAdapter(this.adapter);

        WFScanReceiver= new myReceiver();
        registerReceiver(WFScanReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // When the user clicks SCAN, scan the WiFI environment and show results on screen.
            case R.id.fetch_action:
                //startDownload();
                remainingMeasurements=Integer.parseInt(sharedPrefs.getString("numMeasurements","1"));
                arraylist.clear();
                cumulativeAPList.clear();
                averagedAPList.clear();
                wifi.startScan();
                Toast.makeText(this, remainingMeasurements+" scans remaining", Toast.LENGTH_SHORT).show();
                return true;
            // Clear the text and cancel download.
            case R.id.config_action:
                startActivity(new Intent(this, Prefs.class));
                return true;
            case R.id.send_action:
                POS_ALGORITHM=sharedPrefs.getString("pos_Algorithm", "WKNN");
                URL url;
                //Step 1: let's determine how many RSSI channels are needed
                if(currentNumAPs>maxNumAPs)
                {
                    numRequiredChannels=(channelIDList.length - 1);
                    numSentAPs=maxNumAPs;
                    APsOnLastChannel=3;
                }
                else
                {
                    numSentAPs=currentNumAPs;
                    numRequiredChannels=(int) Math.round(Math.floor(((float) currentNumAPs)/3));
                    APsOnLastChannel=currentNumAPs%3;
                    if(APsOnLastChannel>0)
                        numRequiredChannels++;
                    else
                        APsOnLastChannel=3;

                }
                //Step 2: let's fill in the fields for each channel and send messages
                for (int i=0;i<=numRequiredChannels;i++) {
                    String urlContent=THINGSPEAK_UPDATE_URL + THINGSPEAK_API_KEY_STRING + "="+writeAPIKeyList[i] + "&" + THINGSPEAK_FIELD1 + "=" +android_id;
                    if(i==0)//Channel RSSI1: settings and general information for the positioning request go here
                    {
                        urlContent=urlContent+"&"+THINGSPEAK_FIELD2 +"="+Integer.toString(numSentAPs)+"&"+THINGSPEAK_FIELD3 +"="+POS_ALGORITHM;
                        switch(POS_ALGORITHM){
                            case "KNN":
                            case "WKNN":
                                //Settings for KNN/WKNN
                                metric=sharedPrefs.getString("metric","Minkowski");
                                urlContent=urlContent+"&"+THINGSPEAK_FIELD4 +"="+sharedPrefs.getString("kValue","3")+"&"+THINGSPEAK_FIELD5 +"="+metric;
                                if (metric.equals("Minkowski"))
                                    urlContent=urlContent+"&"+THINGSPEAK_FIELD6 +"="+sharedPrefs.getString("pValue","2");
                            break;
                            case "EWKNN":
                                //Settings for EWKNN
                                metric=sharedPrefs.getString("metric","Minkowski");
                                urlContent=urlContent+"&"+THINGSPEAK_FIELD4 +"="+metric;
                                if(metric.equals("Minkowski"))
                                    urlContent=urlContent+"&"+THINGSPEAK_FIELD5 +"="+sharedPrefs.getString("pValue","2");
                                thresholdStrategy=sharedPrefs.getString("thresholdStrategy","DynamicThreshold");
                                urlContent=urlContent+"&"+THINGSPEAK_FIELD6+"="+thresholdStrategy;
                                if(thresholdStrategy.equals("DynamicThreshold"))
                                    urlContent=urlContent+"&"+THINGSPEAK_FIELD7 +"="+sharedPrefs.getString("threshold1","100")+"&"+THINGSPEAK_FIELD8 +"="+sharedPrefs.getString("threshold1","300");
                            break;
                            case "FIWKNN":
                                //Settings for FI-WKNN
                                kStrategy=sharedPrefs.getString("kStrategy","StaticK");
                                urlContent=urlContent+"&"+THINGSPEAK_FIELD4 +"="+kStrategy;
                                if(kStrategy.equals("StaticK"))
                                    urlContent=urlContent+THINGSPEAK_FIELD5 +"="+sharedPrefs.getString("kValue","3");
                                else
                                    urlContent=urlContent+THINGSPEAK_FIELD5 +"="+sharedPrefs.getString("alphaValue","0.001");
                        }
                        Toast.makeText(this, urlContent, Toast.LENGTH_SHORT).show();
                    }
                    else//Other RSSI channels: we add here the DeviceID and AP address - AP RSSI pairs (three per channel)
                        if(i==numRequiredChannels)
                        {
                            for(int j=0;j<APsOnLastChannel;j++)
                                urlContent=urlContent+"&field"+Integer.toString(2*j+3)+"="+averagedAPList.get(3*(numRequiredChannels-1)+j)[0]+"&field"+Integer.toString(2*j+4)+"="+Float.toString((float) averagedAPList.get(3*(numRequiredChannels-1)+j)[1]);
                        }
                        else
                            for(int j=0;j<3;j++)
                                urlContent=urlContent+"&field"+Integer.toString(2*j+3)+"="+averagedAPList.get(3*(i-1)+j)[0]+"&field"+Integer.toString(2*j+4)+"="+Float.toString((float) averagedAPList.get(3*(i-1)+j)[1]);
                    try {
                        url= new URL(urlContent);
                        new UpdateThingspeakTask().execute(url);
                        Toast.makeText(this, "Data loaded to channel "+(i+1), Toast.LENGTH_SHORT).show();

                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    //finishDownloading();
                    //mDataText.setText("");


                }
                arraylist.clear();
                adapter.notifyDataSetChanged();
                return true;
        }
        return false;
    }

  /*  private void startDownload() {
        if (!mDownloading && mNetworkFragment != null) {
            // Execute the async download.
            mNetworkFragment.startDownload();
            mDownloading = true;
        }
    }*/

    @Override
    public void updateFromDownload(String result) {
        if (result != null) {
            mDataText.setText(result);
        } else {
            mDataText.setText(getString(R.string.connection_error));
        }
    }

    @Override
    public NetworkInfo getActiveNetworkInfo() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo;
    }

    @Override
    public void finishDownloading() {
        mDownloading = false;
        if (mNetworkFragment != null) {
            mNetworkFragment.cancelDownload();
        }
    }

    @Override
    public void onProgressUpdate(int progressCode, int percentComplete) {
        switch(progressCode) {
            // You can add UI behavior for progress updates here.
            case Progress.ERROR:
                break;
            case Progress.CONNECT_SUCCESS:
                break;
            case Progress.GET_INPUT_STREAM_SUCCESS:
                break;
            case Progress.PROCESS_INPUT_STREAM_IN_PROGRESS:
                mDataText.setText("" + percentComplete + "%");
                break;
            case Progress.PROCESS_INPUT_STREAM_SUCCESS:
                break;
        }
    }
    private class myReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context c, Intent I)
        {
            results = wifi.getScanResults();
            size = results.size();
            //APsfound=true;
            remainingMeasurements--;

            size--;
            if (remainingMeasurements >= 0) {
                processMeasurement();
                if (remainingMeasurements == 0) {
                    generateFinalScan();
                    currentNumAPs = averagedAPList.size();
                    showScanResults();
                } else {
                    try {
                        TimeUnit.SECONDS.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getApplicationContext(), remainingMeasurements + " scans remaining", Toast.LENGTH_SHORT).show();
                    //arraylist.clear();
                    wifi.startScan();
                }
            }
            else
                Toast.makeText(getApplicationContext(), "Negative scans remaining, ignoring", Toast.LENGTH_SHORT).show();

        }
        public void processMeasurement()
        {
            if ((remainingMeasurements==numMeasurements-1)||(cumulativeAPList.isEmpty()))//First measurement, let's fill in the averagedAPList array
                while (size >= 0)
                {
                    int levelOfAP=results.get(size).level;
                    if(levelOfAP>-150)
                    {
                        Object [] APEntry= {results.get(size).BSSID,(float) results.get(size).level,1};
                        cumulativeAPList.add(APEntry);
                    }
                    size--;
                }
            else
                while (size >= 0)
                {
                    int AP_found=0;
                    for (Object[] g: cumulativeAPList)
                    {

                        if(((String) g[0]).equals(results.get(size).BSSID)) {
                            g[1] = ((float) g[1]) + results.get(size).level;
                            g[2] = (int) g[2] + 1;
                            AP_found=1;
                            //Toast.makeText(getApplicationContext(), " AP "+g[0]+" found", Toast.LENGTH_SHORT).show();
                        }

                    }
                    if (AP_found==0) {
                        Object[] APEntry = {results.get(size).BSSID, (float) results.get(size).level, 1};
                        cumulativeAPList.add(APEntry);
                    }
                    size--;
                }


        }
        public void generateFinalScan()
        {

            for (Object[] g: cumulativeAPList)
            {
                Object [] averagedAPEntry= {g[0],((float) g[1])/((int)g[2])};
                //Object [] averagedAPEntry= {g[0],g[1]};
                averagedAPList.add(averagedAPEntry);
            }

            Collections.sort(averagedAPList,new Comparator<Object[]>() {
                public int compare(Object[] AP, Object[] otherAPs) {
                    return ((Float) otherAPs[1]).compareTo((Float) AP[1]);
                }
            });

        }
    }
    public void showScanResults()
    {

        if(currentNumAPs>0)
        {
            Toast.makeText(this, currentNumAPs +" Access Points found", Toast.LENGTH_SHORT).show();

            for (Object[] g: averagedAPList)
            {
                HashMap<String, String> item;
                item = new HashMap<String, String>();
                item.put("SSID", (String) g[0]);
                item.put("Level",Float.toString((float) g[1]));
                arraylist.add(item);
            }
            adapter.notifyDataSetChanged();
            if(sharedPrefs.getBoolean("local_storage",true))
                fName=sharedPrefs.getString("TPName","TP_Android_default.txt");
                writeScanToFile(fName,averagedAPList);
        }
        else
        {
            Toast.makeText(this, "No Access Points found...", Toast.LENGTH_SHORT).show();
        }
    }
    public void writeScanToFile(String fName, ArrayList<Object []> APlist)
    {
        String path = Environment.getExternalStorageDirectory() + File.separator  + "ThingsLocate";
        //String path = "ThingsLocate";
        // Create the folder.

        File folder = new File(path);
        if(folder.mkdirs()||folder.isDirectory())
        {
            // Create the file.
            File file = new File(path, fName);
            // Save your stream, don't forget to flush() it before closing it.

            try {
                file.createNewFile();
                FileOutputStream fOut = new FileOutputStream(file);
                OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
                for (Object[] item : APlist)
                    myOutWriter.append(item[0] + " " + item[1] + "\n");
                myOutWriter.close();
                fOut.flush();
                fOut.close();
            } catch (IOException e) {
                Log.e("Exception", "File write failed: " + e.toString());
            }
        }
        else
            Toast.makeText(this, "Could not create dir "+path, Toast.LENGTH_SHORT).show();

    }
    class UpdateThingspeakTask extends AsyncTask<URL, Void, String> {

        private Exception exception;

        protected void onPreExecute() {
        }

        protected String doInBackground(URL... urls) {
            try {
                //URL url = new URL(THINGSPEAK_UPDATE_URL + THINGSPEAK_API_KEY_STRING + "=" +
                        //THINGSPEAK_API_KEY + "&" + THINGSPEAK_FIELD1 + "=" + size +
                        //"&" + THINGSPEAK_FIELD2 + "=" + size);
                HttpURLConnection urlConnection = (HttpURLConnection) urls[0].openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    return stringBuilder.toString();
                }
                finally{
                    urlConnection.disconnect();
                }
            }
            catch(Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                return null;
            }
        }

        protected void onPostExecute(String response) {
            // We completely ignore the response
            // Ideally we should confirm that our update was successful
        }
    }
    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings, menu);

        menu.add(Menu.NONE, 0, 0, "Modify settings");
        menu.add(Menu.NONE, 1, 1, "Scan WiFi signals");
        return super.onCreateOptionsMenu(menu);
    }*/
    /*@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                startActivity(new Intent(this, Prefs.class));
                return true;
        }
        return false;
    }*/

}

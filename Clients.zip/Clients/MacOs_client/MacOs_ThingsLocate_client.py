
# ThingSpeak Update Using MQTT
# Copyright 2016, MathWorks, Inc

#WiFi scan data

    #!/usr/bin/env python
#
# iwlistparse.py
# Hugo Chargois - 17 jan. 2010 - v.0.1
# Parses the output of iwlist scan into a table


# This is an example of publishing to multiple fields simultaneously.
# Connections over standard TCP, websocket or SSL are possible by setting
# the parameters below.
#
# CPU and RAM usage is collected every 20 seconds and published to a
# ThingSpeak channel using an MQTT Publish
#
# This example requires the Paho MQTT client package which
# is available at: http://eclipse.org/paho/clients/python

from __future__ import print_function
import paho.mqtt.publish as publish
import math
import re
import sys
import subprocess
import time

def getMAC(interface='eth0'):
  # Return the MAC address of the specified interface
  args=["/sbin/ifconfig", interface]#, " | grep -Po 'ether \K.*$'"]
  proc = subprocess.Popen(args, stdout=subprocess.PIPE, universal_newlines=True)
  out, err = proc.communicate()
  
  c = re.compile(r'\s+(?P<address_tag>ether)\s+(?P<bssid>(?:[0-9a-f]{1,2}[:]){5}[0-9a-f]{1,2})')
  for line in out.split('\n'):
    #print(line)
    m = c.match(line)
    if m:
      ethernet_data_total = m.groups()
  return ethernet_data_total[1]

###   Start of user configuration   ###   

#  ThingSpeak Channel Settings

# The ThingSpeak Channel ID
# Replace this with the Channel IDs of the RSSI Channels of your TL deployment
channelIDList = ["432763", "432764", "432776", "432777", "432778", "432781", "432782", "432783", "432785", "432786", "432789", "432790", "432793"]
maxNumAPs=(len(channelIDList) - 1)*3
# The Write API Key for the channel
# Replace this with the Write API keys of the RSSI Channels of your TL deployment
writeAPIKeyList = ["TMQQB6B42WE4BOT8", "7G4RCF1591RC1BIL", "GYRZQE8I148V6M1G", "LF44P87U1FI4C468", "LCP4K7O7VNHC1WLH", "F2MR0SCC55PXVBTD", "ER8OML0JJOWHJDJ1", "QRQXFASVNOVDPCG9", "L6IUPR139G0DACFO", "GG7CG6AMHO7OPQM5", "ASVO3H3J4CHX2G67", "THE7ROFCLK9GEIO6", "DZY15YB03XILPFD7"]

#ThingsLocate settings
interface = "en1"
deviceID=getMAC(interface)

#The following lines determine the settings to be adopted in the positioning request, that will be loaded in the RSSI1 channel. A few examples of different onfigurations are available in the comments.
algorithm='WKNN'
settings={'KNN':(3,"Minkowski",2),'WKNN':(3,"Minkowski",2),'EWKNN':("Minkowski",2,"DynamicThreshold",0,0),'FIWKNN':("StaticK",3)}
#settings={'KNN':(3,"Minkowski",2),'WKNN':(3,"Minkowski",2),'EWKNN':("Minkowski",2,"DynamicThreshold",0,0),'FIWKNN':("DynamicK",0.001)} #Example 1: FI-WkNN with dynamic k, uses alpha to determine how many RPs to keep in the estimate
#settings={'KNN':(3,"Minkowski",2),'WKNN':(3,"Minkowski",2),'EWKNN':("Minkowski",2,"StaticThreshold",300,100),'FIWKNN':("StaticK",3)} #Example 2: EWkNN with static thresholds
#settings={'KNN':(3,"Corr",2),'WKNN':(3,"Corr",2),'EWKNN':("Corr",0,"DynamicThreshold",0,0),'FIWKNN':("StaticK",3)}#Example 3: kNN/WkNN/EWkNN with squared Pearson's correlation as similarity metric 

#Use the following two lines for kNN/WkNN
(kValue,metric,pValue)=settings.get(algorithm,(3,"Minkowski",2))
RSSI1Payload ="&field4=" +str(kValue)+ "&field5=" + metric+ "&field6=" + str(pValue)

#Use the following two lines for EWkNN
##(metric,pValue,thresholdStrategy,EWKNNThreshold1,EWKNNThreshold2)=settings.get(algorithm,(3,"Minkowski",2))#for EWkNN
##RSSI1Payload ="&field4=" +metric+  "&field5=" + str(pValue)+ "&field6=" + thresholdStrategy+ "&field7=" + str(EWKNNThreshold1)+ "&field8=" + str(EWKNNThreshold2)

#Use the following two lines for FIWkNN
##(kStrategy,param2Value)=settings.get(algorithm,("StaticK",3))
##RSSI1Payload ="&field4=" +kStrategy+  "&field5=" + str(param2Value)


# MQTT data
#Replace this with your mqttAPIKey
mqttUsername="TLDemo"
mqttAPIKey="CJNUPUFBRSJQDKN2"

#  MQTT Connection Methods

# Set useUnsecuredTCP to True to use the default MQTT port of 1883
# This type of unsecured MQTT connection uses the least amount of system resources.
useUnsecuredTCP = False

# Set useUnsecuredWebSockets to True to use MQTT over an unsecured websocket on port 80.
# Try this if port 1883 is blocked on your network.
useUnsecuredWebsockets = True

# Set useSSLWebsockets to True to use MQTT over a secure websocket on port 443.
# This type of connection will use slightly more system resources, but the connection
# will be secured by SSL.
useSSLWebsockets = False

###   End of user configuration   ###

# The Hostname of the ThinSpeak MQTT service
mqttHost = "mqtt.thingspeak.com"

# Set up the connection parameters based on the connection type
if useUnsecuredTCP:
    tTransport = "tcp"
    tPort = 1883
    tTLS = None

if useUnsecuredWebsockets:
    tTransport = "websockets"
    tPort = 80
    tTLS = None

if useSSLWebsockets:
    import ssl
    tTransport = "websockets"
    tTLS = {'ca_certs':"/etc/ssl/certs/ca-certificates.crt",'tls_version':ssl.PROTOCOL_TLSv1}
    tPort = 443

def send_message(table):
#This function takes care of sending the positioning request to the ThingSpeak server
    topicList=[]
    #Step 1: let's determine how many RSSI channels are needed
    numDetectedAPs=len(table)
    print("Number of detected APs: "+str(numDetectedAPs))
    if numDetectedAPs>=maxNumAPs:
        numRequiredChannels=len(channelIDList) - 1
        numSentAPs=maxNumAPs
        APsOnLastChannel=3
    else:
        numSentAPs=numDetectedAPs
        numRequiredChannels=int(math.floor(numDetectedAPs/3))
        APsOnLastChannel=numDetectedAPs%3
        if APsOnLastChannel>0:
            numRequiredChannels=numRequiredChannels+1
        else:
            APsOnLastChannel=3
    print("Number of required channels: "+str(numRequiredChannels))
    print("Number of APs on last channel: "+str(APsOnLastChannel))
    #Step 2: let's fill in the fields for each channel and send messages
    for i in range(numRequiredChannels+1):
        topic = "channels/" + channelIDList[i] + "/publish/" + writeAPIKeyList[i]
        topicList.append(topic)
        if i==0:
            #Channel RSSI1: settings and general information for the positioning request go here 
            tPayload ="field1=" + deviceID+ "&field2=" + str(numSentAPs)+ "&field3=" + algorithm+RSSI1Payload
            #print(tPayload)
        elif i==numRequiredChannels:
            #Other RSSI channels: we add here the DeviceID and AP address - AP RSSI pairs (three per channel)           
            tPayload = "field1="+ deviceID;
            for j in range(APsOnLastChannel):               
                tPayload = tPayload+"&field"+str(2*j+3)+"="+str(table[3*(numRequiredChannels-1)+j][0])+"&field"+str(2*j+4)+"="+str(table[3*(numRequiredChannels-1)+j][1])
        else:
            tPayload = "field1="+ deviceID;
            for j in range(3):
                tPayload = tPayload+"&field"+str(2*j+3)+"="+str(table[3*(i-1)+j+1][0])+"&field"+str(2*j+4)+"="+str(table[3*(i-1)+j+1][1])
        publish.single(topic, payload=tPayload, hostname=mqttHost, transport=tTransport, port=tPort,auth={'username':mqttUsername,'password':mqttAPIKey})

def update_table(table,sr_table):
#This function updates the table of AP-RSSI readings after each new scan.
#- the "table" array contains the cumulated data of all scans carried out so far
#- the "sr_table" array contains data from the current scan  
#first we check if "table" already exists
  if not table:
    newTable=True
  else:
    newTable=False    
  for sr_table_entry in sr_table:
   #for each entry in sr_table if "table" did not exist we add the AP MAC Address.
    if newTable:
      sr_table_entry.append(1)
      table.append(sr_table_entry)
    else: #otherwise we check if it was already detected before.
      found=False
      for table_entry in table:        
        if sr_table_entry[0] in table_entry:
        #If this is the case, we add the corresponding RSSI value to the cumulative value stored in "table".
          table_entry[1]=table_entry[1]+sr_table_entry[1]
        #We also increase the corresponding counter, needed to eventually determine the average RSSI value for that AP.
          table_entry[2]=table_entry[2]+1
          found=True
      if not found:
        #Otherwide, we add a new entry in "table".
         sr_table_entry.append(1)
         table.append(sr_table_entry)
  #print(table)

def generate_averaged_measurements(table,average):
  #This function takes the average of RSSI readings after all scans are completed and stored in "table".
  #The "average" array will be used to send data to ThingSpeak.
    for table_entry in table:
      av_entry=[]
      av_entry.append(table_entry[0]);
      av_entry.append(table_entry[1]/table_entry[2]);
      average.append(av_entry)

def print_TP(average):
  #This function writes data to a local file, mainly for debugging or local processing.
  f=open("TP_RPi_test.txt","w+")
  for ap in average:
    f.write("%s %f\n" % (ap[0], ap[1]))
  f.close()

def scan(sr_table):
  #The script uses the "airport" system utility in order to get scans of available WiFi APs.
  airportPath="/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"
  args=[airportPath, "-s"]
  proc = subprocess.Popen(args, stdout=subprocess.PIPE, universal_newlines=True)
  out, err = proc.communicate()
  c = re.compile(r'\s+(?P<ssid>.*)\s+(?P<bssid>(?:[0-9a-f]{1,2}[:]){5}[0-9a-f]{1,2})\s(?P<rssi>[-]?\d+)\s+(?P<channel>[\d,-]+|[\d,+]+)\s+.*')
  for line in out.split('\n'):
    m = c.match(line)
    if m:
      AP_data_total = m.groups()
      AP_data_needed=[]
      AP_data_needed.append(AP_data_total[1])
      AP_data_needed.append(int(AP_data_total[2]))      
      sr_table.append(AP_data_needed)
  #print(sr_table)
def main():
  #This function executes a set of "numMeasurement" WiFi scans, stores them in the "average" array, and passes the array to the
  #functions in charge of sending data to ThingSpeak and of storing them in a local file.
    average=[]
    sorted_average=[]
    numMeasurements=1
    for i in range(numMeasurements):
      print("Measurement ", i, " out of ", numMeasurements, "\n")
      single_run_table=[]
      if i==0:
        table=[]
      scan(single_run_table)
      #print("after scan\n")
      update_table(table,single_run_table)
      #print("after update_table\n")
      #The timeout below is also platform specific. On Raspbian, when iwlist is invoked results are cached by the system, and if iwlist is invoked a second time in less than about 30s the cached scan is returned in stead of a new one.
      #The timeout ensures that each iwlist execution indeed returns a new scan.
      time.sleep(20)
    #print(table)
    generate_averaged_measurements(table,average)
    #print(average)
    sorted_average=sorted(average, key=lambda table: table[1], reverse=True)
    print_TP(sorted_average)
    send_message(sorted_average)
    
main()
